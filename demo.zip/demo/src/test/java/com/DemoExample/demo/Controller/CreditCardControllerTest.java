package com.DemoExample.demo.Controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.CreditCardsDetails.demo.Dao.CreditCardRepository;
import com.CreditCardsDetails.demo.Model.CreditCardDetail;
import com.CreditCardsDetails.demo.Service.CreditCardService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ankbisht
 *
 */
@WebMvcTest
@RunWith(SpringJUnit4ClassRunner.class)
public class CreditCardControllerTest {

	@MockBean
	CreditCardService creditCardService;

	@MockBean
	CreditCardRepository creditCardRepository;

	@Autowired
	MockMvc mockMvc;

	private static ObjectMapper mapper = new ObjectMapper();

	@Test
	void testInsertMovie() throws Exception {
		CreditCardDetail creditCard = new CreditCardDetail(1, "Visa", 12345, "Ankit", 1000);
		Mockito.when(creditCardRepository.save(creditCard)).thenReturn(creditCard);
		String json = mapper.writeValueAsString(creditCard);
		String url = "/creditCard";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(url).accept(MediaType.APPLICATION_JSON)
				.content(json).contentType(MediaType.APPLICATION_JSON);
		MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
		String result = mvcResult.getResponse().getContentAsString();
		CreditCardDetail creditCardDetail = new ObjectMapper().readValue(result, CreditCardDetail.class);
		assertEquals(1, creditCardDetail.getId());
	}

}
