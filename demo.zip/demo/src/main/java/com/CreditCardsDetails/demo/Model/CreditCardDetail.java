package com.CreditCardsDetails.demo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ankbisht
 *
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreditCardDetail {
	@Id
	@GeneratedValue
	private int id;
	private String cardName;
	private double cardNumber;
	private String cardHolderName;
	private double monthlyLimit;

	public CreditCardDetail() {

	}

	/**
	 * @param id
	 * @param cardName
	 * @param cardNumber
	 * @param cardHolderName
	 * @param monthlyLimit
	 */
	public CreditCardDetail(int id, String cardName, double cardNumber, String cardHolderName, double monthlyLimit) {
		this.id = id;
		this.cardName = cardName;
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.monthlyLimit = monthlyLimit;
	}

	/**
	 * @return the cardName
	 */
	public String getCardName() {
		return cardName;
	}

	/**
	 * @param cardName the cardName to set
	 */
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	/**
	 * @return the cardNumber
	 */
	public double getCardNumber() {
		return cardNumber;
	}

	/**
	 * @param cardNumber the cardNumber to set
	 */
	public void setCardNumber(double cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * @return the cardHolderName
	 */
	public String getCardHolderName() {
		return cardHolderName;
	}

	/**
	 * @param cardHolderName the cardHolderName to set
	 */
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	/**
	 * @return the monthlyLimit
	 */
	public double getMonthlyLimit() {
		return monthlyLimit;
	}

	/**
	 * @param monthlyLimit the monthlyLimit to set
	 */
	public void setMonthlyLimit(double monthlyLimit) {
		this.monthlyLimit = monthlyLimit;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "CreditCardDetail [id=" + id + ", cardName=" + cardName + ", cardNumber=" + cardNumber
				+ ", cardHolderName=" + cardHolderName + ", monthlyLimit=" + monthlyLimit + "]";
	}

}
