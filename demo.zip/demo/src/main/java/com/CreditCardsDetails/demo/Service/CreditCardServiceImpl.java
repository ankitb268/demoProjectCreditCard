package com.CreditCardsDetails.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CreditCardsDetails.demo.CreditCardsDetails;
import com.CreditCardsDetails.demo.Dao.CreditCardRepository;
import com.CreditCardsDetails.demo.Model.CreditCardDetail;

/**
 * @author ankbisht
 *
 */
@Service
public class CreditCardServiceImpl implements CreditCardService{

	@Autowired
	CreditCardRepository creditCardRepository;
	@Override
	public CreditCardDetail addCreditCardDetail(CreditCardDetail creditCardDetail) {
		
		return creditCardRepository.save(creditCardDetail);
	}
	@Override
	public List<CreditCardDetail> getCreditCardDetails() {
		return creditCardRepository.findAll();
	}

}
