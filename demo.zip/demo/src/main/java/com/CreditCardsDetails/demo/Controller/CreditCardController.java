package com.CreditCardsDetails.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CreditCardsDetails.demo.CreditCardsDetails;
import com.CreditCardsDetails.demo.Model.CreditCardDetail;
import com.CreditCardsDetails.demo.Service.CreditCardService;

/**
 * @author ankbisht
 *
 */
@RestController
@RequestMapping("/v1/demoExample")
public class CreditCardController {

	@Autowired
	CreditCardService creditCardService;

	@PostMapping("/creditCard")
	public CreditCardDetail saveCreditCard(@RequestBody CreditCardDetail creditCard) {
		return this.creditCardService.addCreditCardDetail(creditCard);
	}
	
	@GetMapping("/getCreditCards")
	public List<CreditCardDetail> getAllDetails(){
		return this.creditCardService.getCreditCardDetails();
		
	}
}
