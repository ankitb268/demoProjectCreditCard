package com.CreditCardsDetails.demo.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CreditCardsDetails.demo.Model.CreditCardDetail;

/**
 * @author ankbisht
 *
 */
public interface CreditCardRepository extends JpaRepository<CreditCardDetail, Integer>{

}
