package com.CreditCardsDetails.demo.Service;

import java.util.List;

import com.CreditCardsDetails.demo.CreditCardsDetails;
import com.CreditCardsDetails.demo.Model.CreditCardDetail;

/**
 * @author ankbisht
 *
 */
public interface CreditCardService {

	public CreditCardDetail addCreditCardDetail(CreditCardDetail creditCardDetail);

	public List<CreditCardDetail> getCreditCardDetails();
}
